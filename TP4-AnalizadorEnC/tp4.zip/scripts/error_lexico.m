inicio 
          id:= 4/4;
fin