inicio 
    leer (a)
fin