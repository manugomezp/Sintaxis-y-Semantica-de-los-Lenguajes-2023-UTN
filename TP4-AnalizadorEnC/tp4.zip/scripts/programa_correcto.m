inicio 
    var := 4;
    leer (var);
fin